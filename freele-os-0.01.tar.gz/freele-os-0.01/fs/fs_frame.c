/*
fs.c:

Copyright (C) 2014  Michael. Th. Zhang <zth@pku.edu.cn> or <muge0913@sina.com>

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see http://www.gnu.org/licenses/.
*/

#include <string.h>
#include <fs_frame.h>

static unsigned int isfirstcall_fs = 0;

void file_system_init()
{
    for(int index = 0;index < MAX_SUPER_BLOCK;index ++)
        fs_type[index] = NULL;
}
int register_file_system(struct super_block *type,unsigned int id)
{

    if(id < 0 || id > MAX_SUPER_BLOCK)
        return -1;

    if(!isfirstcall_fs){
        file_system_init();
    }

 	if(fs_type[id]==NULL){
		fs_type[id]=type;
		return 0;
	}
	return -1;
}

int unregister_file_system(struct super_block *type,unsigned int id)
{
    
    if(id < 0 || id > MAX_SUPER_BLOCK)
        return -1;

	if(fs_type[id] != NULL){
        fs_type[id] = NULL;
        return 0;
    }
    return -1;
   
}
int  read_file_system(unsigned int file_system_id,void *buf,char *dir)
{
    if(file_system_id < 0 || file_system_id > MAX_SUPER_BLOCK)
        return -1;

    struct inode *node = fs_type[file_system_id]->namei(fs_type[file_system_id],dir);//每个文件系统namei的实现方法不同，与文件系统的数据结构有关
     //与该文件系统相对应的存储介质读取方法
    int ret = read_storage_device(fs_type[file_system_id]->device_id,buf,fs_type[file_system_id]->get_daddr(node),node->dsize);
    return ret;

}

int write_file_system(unsigned int file_system_id,void *buf,char * dir)
{
    if(file_system_id < 0 || file_system_id > MAX_SUPER_BLOCK)
        return -1;

/*    struct inode *node = fs_type[file_system_id]->namei(fs_type[file_system_id],dir);
    int ret = write_storage_device(fs_type[file_system_id]->device_id,\
                                buf,\
                                fs_type[file_system_id]->get_daddr(node),\
                                node->dsize);
    return ret;*/

}
