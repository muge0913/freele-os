/*
fs_frame.h:

Copyright (C) 2014  Michael. Th. Zhang <zth@pku.edu.cn> or <muge0913@sina.com>

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see http://www.gnu.org/licenses/.
*/


#ifndef __FS_H__
#define __FS_H__
 
#include <dr_frame.h>
/* 支持的最大文件系统类型数*/
#define MAX_SUPER_BLOCK	(8)
/* 文件系统号*/
#define ROMFS	(0)

/* 文件系统数据结构*/
struct super_block {
	struct inode *(*namei)(struct super_block *super,char *p);// namei函数指针，不同的文件系统namei实现的方法不一样
	unsigned int (*get_daddr)(struct inode *);//得到实际的文件地址
	struct storage_device *device;//该文件系统所在的存储设备类型
	unsigned int device_id;//该文件系统所在的存储设备设备号
    int (* xxxdisk_init)();
	char *name;//该文件系统的名称
};
/* 索引节点数据结构*/
struct inode {
	char *name;//索引节点所代表的文件名
	unsigned int flags;
	size_t dsize;//索引节点指向文件的大小
	unsigned int daddr;	//文件在存储器中的存放位置
	struct super_block *super;
	
};

struct super_block *fs_type[MAX_SUPER_BLOCK];
void file_system_init();
int register_file_system(struct super_block *type,unsigned int id);
int unregister_file_system(struct super_block *type,unsigned int id);
int read_file_system(unsigned int file_system_id,void *buf,char * dir);
int write_file_system(unsigned int file_system_id,void *buf,char * dir);
#endif
