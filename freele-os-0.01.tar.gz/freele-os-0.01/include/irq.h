/*
irq.h:

Copyright (C) 2014  Michael. Th. Zhang <zth@pku.edu.cn> or <muge0913@sina.com>

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see http://www.gnu.org/licenses/.
*/


#ifndef __IRQ_H__
#define __IRQ_H__

/* 中断控制寄存器*/
#define VIC0INTSELECT  (*(volatile unsigned *)(0x7120000c))
#define VIC1INTSELECT  (*(volatile unsigned *)(0x7130000c))

#define VIC0INTENABLE  (*(volatile unsigned *)(0x71200010))
#define VIC1INTENABLE  (*(volatile unsigned *)(0x71300010))

#define VIC0INTENCLEAR (*(volatile unsigned *)(0x71200014))
#define VIC1INTENCLEAR (*(volatile unsigned *)(0x71300014))

#define EINT0FLTCON0       (*(volatile unsigned *)(0x7F008910))

#define VIC0VECTADDR      ((volatile unsigned *)(0x71200100))
#define VIC1VECTADDR      ((volatile unsigned *)(0x71300100))
#define VIC0ADDRESS        (*(volatile unsigned *)(0x71200f00))
#define VIC1ADDRESS        (*(volatile unsigned *)(0x71300f00))

/* 最大中断源数*/
#define MAX_INT_NUM	    (64)

static inline void enable_irq()
{
        __asm__  volatile (
        "mrs r4,cpsr\n"
        "bic r4,r4,#0x80\n"
        "msr cpsr,r4\n"
        :::"r4");
}

static inline void disable_irq()
{
	__asm__ volatile (
		"mrs r4,cpsr\n"
		"orr r4,r4,#0x80\n"
		"msr cpsr,r4\n"
		:::"r4");
}

static inline  void save_context()
{
    __asm__ volatile(
		"sub lr,lr,#4\n"
		"stmfd sp!,{r0-r12,lr}\n"
		);
}

static inline void restore_context()
{
	__asm__ volatile(
		"ldmfd sp!,{r0-r12, pc}^\n"
		);
}

/*Ensure CP15 Register VIC Enable bit is set in ARM Core*/
static inline void enable_vic_port(void)
{
	__asm__ volatile(
		"mrc p15,0,r0,c1,c0,0\n"
		"orr r0,r0,#(1<<24)\n"
		"mcr p15,0,r0,c1,c0,0\n"
		:::"r0");
}

static inline unsigned get_cpsr(void)
{
	unsigned int retval;
	__asm__ volatile(
	"mrs %0,cpsr":"=r"(retval):);
	return retval;
}
static inline void set_cpsr(unsigned val)
{
	__asm__ volatile(
	"msr cpsr,%0":/*no output*/:"r"(val));
}
static inline void finish_service_routine()
{
	VIC0ADDRESS = 0;
	VIC1ADDRESS = 0;
}
/* 打开int_num中断源*/
static inline int enable_int(unsigned int int_num)
{
    if(int_num > MAX_INT_NUM){
        return -1;
     }

    if(int_num<32){
	VIC0INTENABLE |= (1<<int_num);
     }else{
	VIC1INTENABLE |= (1<<(int_num -32));
     }
     
     return 0;
}

/* 设置某一个中断为快速中断*/
static inline int select_fiq_int(unsigned int int_num)
{

    if(int_num > MAX_INT_NUM){
        return -1;
    }
    if(int_num<32){
	VIC0INTSELECT |= (1<<int_num);
    }else{
	VIC1INTSELECT |= (1<<(int_num - 32));
    }
    return 0;
}
/* 设置某一个中断为irq中断*/
static inline int select_irq_int(unsigned int int_num)
{

    if(int_num > MAX_INT_NUM){
        return -1;
    }
    if(int_num<32){
	VIC0INTSELECT &= ~(1<<int_num);
    }else{
	VIC1INTSELECT &= ~(1<<(int_num - 32));
    }
    return 0;
}
/* 与一个中断源相关连一个中断服务程序*/
static inline void set_service_routine(unsigned int int_num, void (*isr)(void))
{
  if(int_num > MAX_INT_NUM){
        return;
  }   
  if(int_num < 32){
        VIC0VECTADDR[int_num] = (unsigned)isr;
  }else{
        VIC1VECTADDR[int_num-32] = (unsigned)isr;
  }
}


#endif
