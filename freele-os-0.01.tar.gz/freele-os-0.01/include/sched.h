/*
sched.h:

Copyright (C) 2014  Michael. Th. Zhang <zth@pku.edu.cn> or <muge0913@sina.com>

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see http://www.gnu.org/licenses/.
*/


#ifndef __SCHED_H__
#define __SCHED_H__
/*系统最大任务数，包括内核*/
#define MAX_TASK_NUM    (3)

struct task_struct {
/* these are hardcoded - don't touch */
	long state;	/* -1 unrunnable, 0 runnable, >0 stopped */
	long priority;
	long signal;
	long blocked;	/* bitmap of masked signals */
/* various fields */
	unsigned long start_code,end_code,end_data,brk,start_stack;
};

void init_app_context(unsigned int app_start)
{
    /* 堆栈指针指向应用程序2k的尾处*/
    unsigned int *p = (unsigned int *)(app_start + 0x800);
    /*堆栈是满递减的所以*/
    p --;
    *p = app_start;
    p--;
    for (int i= 13;i > 0;i--,p--) {
        *p = 0;
    }

}

static void save_context_for_sched(unsigned int index)
{
    if(index == 0){//保存系统堆 栈暂时使用这个地址吧
    __asm__ volatile(
		"sub lr,lr,#4\n"
        "ldr sp,=0x50300800\n"
		"stmfd sp!,{r0-r12,lr}\n"
		);
    }  
    else if (index == 1) {//保存到用和设定的堆栈中    
    __asm__ volatile(
		"sub lr,lr,#4\n"
        "ldr sp,=0x50100800\n"
		"stmfd sp!,{r0-r12,lr}\n"
		);
    } 
    else if( index == 2) {//保存到用和设定的堆栈中    
    __asm__ volatile(
		"sub lr,lr,#4\n"
        "ldr sp,=0x50200800\n"
		"stmfd sp!,{r0-r12,lr}\n"
		);
    } 
}
static void restore_context_for_sched(unsigned int index)
{
    if (index == 0){ 
	__asm__ volatile(
        "ldr sp,=0x503007c8\n"
		"ldmfd sp!,{r0-r12, pc}^\n"
		);
    }
    else if (index == 1){  
	__asm__ volatile(
        "ldr sp,=0x501007c8\n"
		"ldmfd sp!,{r0-r12, pc}^\n"
		);
    }
    else if (index == 2){    
	__asm__ volatile(
        "ldr sp,=0x502007c8\n"
		"ldmfd sp!,{r0-r12, pc}^\n"
		);
    } 
}
static inline void sched() 
{
    static unsigned int index_for_sched = 0;

    save_context_for_sched(index_for_sched % MAX_TASK_NUM);
    restore_context_for_sched((index_for_sched + 1) % MAX_TASK_NUM);

    index_for_sched ++;
}

#endif
