/*
main.c:

Copyright (C) 2014  Michael. Th. Zhang <zth@pku.edu.cn> or <muge0913@sina.com>

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see http://www.gnu.org/licenses/.
*/


#include <dr_frame.h>
#include <fs_frame.h>
#include <irq.h>

extern void led_port_init();
extern void led_display(int data);
extern void led_delay();
extern void uart0_init();
extern void uart0_send_string(char* pt);
extern void printk(const char *fmt, ...);

extern void init_page_map(void);
extern int  kmalloc_init(void);
extern void *kmalloc(unsigned int size);
extern void kfree(void *addr);

extern int romfs_init();
extern int ramdisk_driver_init();

extern void irq_k1_init(void);
extern int exec(unsigned char *binary_filename);
extern int exec_for_test(unsigned int startaddr);
extern void s3c6410_nand_copy_to_sdram(unsigned int nand_start, unsigned int ddr_start, unsigned int len);

unsigned int get_pc_value(void)
{
	unsigned int addr = 0;
	__asm__(
		"mov %0,pc\n"
		: "+r"(addr));
	return addr;
}

/* 内核初始化*/
int main(int program_size,char ** arm)
{
    /* 串口初始化*/
    uart0_init();
    /*led port*/
    led_port_init();
    /*for k1 and system timer*/
    enable_vic_port();

    irq_k1_init();
    enable_irq();

    /*验证内核程序是否正确拷贝*/   
    unsigned int *program_p = (unsigned int *)(0x50000000); 
    for(int index = 0;index < program_size;index +=4,program_p ++){
        printk("%x",*program_p);  
        if(index % 30 == 0 )
            printk("\n\r");
    }

    printk("\n\r");
    /*系统内存管理初始化*/
    init_page_map();
    kmalloc_init();
    char *p1;
    p1=kmalloc(127);
    printk("the first alloced address is %x\n\r",p1);
    
	
    storage_device_init();//存储设备初始化
    printk("storage_device_init\n\r");
    
    file_system_init();//文件系统初始化
    printk("file_system_init\n\r");
    
    ramdisk_driver_init();
    printk("ramdisk_driver_init\n\r");
   
    romfs_init();
    printk("romfs_init\n\r");
   
    /*检测文件系统是否正确下载*/
    unsigned char *p=(unsigned char *)(0x50100000);
    s3c6410_nand_copy_to_sdram(0x3000000, 0x50100000,8);
    for(int i =0;i < 8;i++) { 
        printk("%c",p[i]);
    } 
    printk("\n\r");

    /*读取文件系中的helloworld.txt文件*/
    unsigned char romfsbuf[15];
    read_file_system(ROMFS,romfsbuf,"helloworld.txt");
    printk("read_file_system,helloworld.txt:");
    printk("%s\n\r",romfsbuf);
    
    /*读取文件系中的file1文件*/
    read_file_system(ROMFS,romfsbuf,"file1");
    printk("read_file_system,file1:");
    printk("%s\n\r",romfsbuf);

    /*检测ramdis功能*/
    unsigned char buf_ramdisk[128];
    unsigned char buf_ramdisk2[128];
    for(int index =0;index <128;index ++)
        buf_ramdisk[index] = index;

    write_storage_device(RAMDISK,buf_ramdisk,0,128);
    read_storage_device(RAMDISK,buf_ramdisk2,0,128);

    for(int ramdisk_index = 0;ramdisk_index < 128;ramdisk_index ++){
       printk("%x  ",buf_ramdisk2[ramdisk_index]);
       if(ramdisk_index % 20 == 0)
            printk("\n\r");
    } 

    /* 显示当前pc值just for fun*/
    printk("pc addr:%x\n\r", get_pc_value());
    /* 执行文件系统中的应用程序*/
    unsigned char *app_addr = (unsigned char *)(0x50100000);
    read_file_system(ROMFS,app_addr,"task_one.bin");
    app_addr = (unsigned char *)(0x50200000);
    read_file_system(ROMFS,app_addr,"task_two.bin");
    
    init_app_context(0x50100000);
    init_app_context(0x50200000);
    /*初始化系统时钟，进入多任务*/
    sys_timer0_init();

     for(;;) { 
        led_display(0x1); //
	    led_delay();
        led_display(0x2); // 
	    led_delay();
	    led_display(0x4); // 
	    led_delay();
	    led_display(0x8); // 
	    led_delay();
    }

    return 0;
}
