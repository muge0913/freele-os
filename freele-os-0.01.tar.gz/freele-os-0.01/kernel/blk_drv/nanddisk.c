/*
nanddisk.c:

Copyright (C) 2014  Michael. Th. Zhang <zth@pku.edu.cn> or <muge0913@sina.com>

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see http://www.gnu.org/licenses/.
*/



/* 说明nanddisk区域来存放romfs文件系统*/
#include <dr_frame.h>
/* S3C6410的NAND Flash处理函数 */
extern void s3c6410_nand_write(unsigned int nand_start, unsigned char * buf, unsigned int len);
extern void s3c6410_nand_read(unsigned int nand_start, unsigned char *buf, unsigned int len);

/* nanddisk的大小128MB*/
#define NANDDISK_SIZE    	    (128*1024*1024)
/* 设置成文件系统存放的地址*/
#define NANDDISK_ADDR    	    (0x3000000)
#define NANDDISK_SECTOR_SIZE 	(1024)
/* 把数据读出放入dest处*/
int nanddisk_dout(struct storage_device *sd,void *dest,unsigned int addr,size_t size){
	s3c6410_nand_read((addr+sd->start_pos),(unsigned char *)dest,size);
	return 0;
}

/* 把数据写入到dest的地址*/
int nanddisk_din(struct storage_device *sd,void *addr,unsigned int dest,size_t size){
	s3c6410_nand_write((dest+sd->start_pos), (unsigned char *)addr,size);
	return 0;
}

static struct storage_device nanddisk_storage_device={
	.dout = nanddisk_dout,
    .din = nanddisk_din,
	.sector_size = NANDDISK_SECTOR_SIZE,
	.storage_size = NANDDISK_SIZE,
	.start_pos = NANDDISK_ADDR
};
int nanddisk_driver_init(){
    return register_storage_device(&nanddisk_storage_device,NANDDISK);
}

