/*
s3c6410_nand.c:

Copyright (C) 2014  Michael. Th. Zhang <zth@pku.edu.cn> or <muge0913@sina.com>

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see http://www.gnu.org/licenses/.
*/



#define PAGE_SIZE       8192

#define NFCONF      (*(volatile unsigned long*)(0x70200000))
#define NFCONT      (*(volatile unsigned long*)(0x70200004))
#define NFCMMD      (*(volatile unsigned long*)(0x70200008))
#define NFADDR      (*(volatile unsigned long*)(0x7020000C))
#define NFDATA      (*(volatile unsigned char*)(0x70200010))
#define NFSTAT      (*(volatile unsigned long*)(0x70200028))
#define GPOCON      (*(volatile unsigned long*)(0x7F008140))
#define GPOPUD      (*(volatile unsigned long*)(0x7F008148))
#define GPPCON      (*(volatile unsigned long*)(0x7F008160))
#define GPPPUD      (*(volatile unsigned long*)(0x7F008168))
#define MEM_SYS_CFG (*(volatile unsigned long*)(0x7E00F120))

/* �ȴ�NAND Flash���� */
static void s3c6410_nand_wait_idle(void){
    /* NFSTAT�Ĵ���0λΪ0��ʱ��Ϊbusy��1��ʱ��Ϊ���� */
    while(!(NFSTAT & 0x1));
}

/* ����Ƭѡ�ź� */
static void s3c6410_nand_select_chip(void){
    NFCONT &= ~(1<<1);   
}

/* ȡ��Ƭѡ�ź� */
static void s3c6410_nand_deselect_chip(void){
    NFCONT |= (1<<1);
}

/* �������� */
static void s3c6410_nand_write_cmd(unsigned char cmd){
    /* NFCMD�Ĵ����ǵ�8λ��Ч */
    NFCMMD = cmd;
}

/* ������ַ */
static void s3c6410_nand_write_addr(unsigned long addr){
    unsigned long row   = addr/PAGE_SIZE;
    unsigned long column = addr%PAGE_SIZE;
    
    
    NFADDR = column & 0xff;
    NFADDR = (column >> 8) & 0xff;

    NFADDR = row & 0xff;
    NFADDR = (row >> 8) & 0xff;
    NFADDR = (row >> 16) & 0xff;
}

/* ��λ */
static void s3c6410_nand_reset(void){
    
    s3c6410_nand_select_chip();
    s3c6410_nand_write_cmd(0xff);  // ��λ����
    s3c6410_nand_wait_idle();
    s3c6410_nand_deselect_chip();
}

/* ��ȡ�����ֽ����� */
unsigned char s3c6410_nand_read_data(void){
    return NFDATA;
}
/* ������������,nand_startΪԴ��ַ,�õ�ַ��nandflash�е�
 * ddr_startΪĿ���ַ���õ�ַ���ڴ��У�lenΪҪ��ȡ�ĳ���
 */
void s3c6410_nand_copy_to_sdram(unsigned int nand_start, unsigned int ddr_start, unsigned int len){
	unsigned long rest = len;
	unsigned long addr = nand_start;
	unsigned long page;
	unsigned char *dest = (unsigned char *)ddr_start;
	int i;

	s3c6410_nand_select_chip();
	while(rest > 0){
		s3c6410_nand_write_cmd(0x00);
		s3c6410_nand_write_addr(addr);
		s3c6410_nand_write_cmd(0x30);
		s3c6410_nand_wait_idle();

		page = rest>PAGE_SIZE?PAGE_SIZE:rest;
		for(i = 0; i != page; ++i){
			*dest++ = NFDATA;
		}
		rest -= page;
		addr += page;
	}
	s3c6410_nand_deselect_chip();
}
/* ��nandflash����len���ȵ����ݵ���ָ����buf�У�buf���ڴ��� */
void s3c6410_nand_read(unsigned int nand_start, unsigned char *buf, unsigned int len){
	unsigned long rest = len;
	unsigned long addr = nand_start;
	unsigned long page;
	unsigned char *dest = (unsigned char *)buf;
	int i;

	s3c6410_nand_select_chip();
	while(rest > 0){
		s3c6410_nand_write_cmd(0x00);
		s3c6410_nand_write_addr(addr);
		s3c6410_nand_write_cmd(0x30);
		s3c6410_nand_wait_idle();

		page = rest>PAGE_SIZE?PAGE_SIZE:rest;
		for(i = 0; i != page; ++i){
			*dest++ = NFDATA;
		}
		rest -= page;
		addr += page;
	}
	s3c6410_nand_deselect_chip();
}
/* �������� */
void s3c6410_nand_erase(unsigned long addr){
	int page = addr/PAGE_SIZE;

	s3c6410_nand_select_chip();

	s3c6410_nand_write_cmd(0x60);
	NFADDR = page&0xff;
	NFADDR = (page>>8)&0xff;
	NFADDR = (page>>16)&0xff;

	s3c6410_nand_write_cmd(0xd0);
	s3c6410_nand_wait_idle();

	s3c6410_nand_deselect_chip();
}
/* S3C6410��NAND Flash�������� */
void s3c6410_nand_init(){
#define TACLS 7
#define TWRPH0 7
#define TWRPH1 7

	GPOCON = (GPOCON & ~0xf) | 0xa;//nCS[3:2]
	GPOPUD &= ~0xf;
	GPPCON = (GPPCON & ~(0xfff << 4)) | (0xaaa << 4);//nWAIT, FALE, FCLE,
	GPPPUD &= ~(0xfff << 4);//FWEn, FREn, FRnB

	MEM_SYS_CFG &= ~(1<<1);
	NFCONF &= ~((0x7<<4)|(0x7<<8)|(0x7<<12)|(1<<30));
	NFCONF |= (TWRPH1<<4)|(TWRPH0<<8)|(TACLS<<12);
	NFCONT |= 1;
	NFCONT &= ~(1<<16);
         /* ��λNAND Flash */
        s3c6410_nand_reset();

}
/* д������,��buf�е����ݣ�д�뵽nandflash��nand_start��ַ�� */
void s3c6410_nand_write(unsigned int nand_start, unsigned char * buf, unsigned int len){
	unsigned long count = 0;
	unsigned long addr  = nand_start;
	int i = nand_start % PAGE_SIZE;

	s3c6410_nand_select_chip();
	while (count < len){
		s3c6410_nand_write_cmd(0x80);
		s3c6410_nand_write_addr(addr);
		for (; i < PAGE_SIZE && count < len; i++){
			NFDATA = buf[count++];
			addr++;
		}
		s3c6410_nand_write_cmd(0x10);
		s3c6410_nand_wait_idle();
		i = 0;
	}
	s3c6410_nand_deselect_chip();
}
/* ��nand�е�0��ַ����length�������ݶ�ȡ��sdram��0��ַ�� */
void copy2sdram(unsigned long length){
	unsigned long rest = length;
	unsigned long size;
	unsigned long i;

	/* nand flash ���˵� steppingstone�е�8k�Ǵ�ŵ�4��ҳ�е� */
	for(i = 0; i != 4; ++i){
		size = rest>2048?2048:rest;
		s3c6410_nand_copy_to_sdram(PAGE_SIZE*i, 0x50000000+i*2048, size);
		rest -= size;
		if(rest == 0)
		return;
	}

	s3c6410_nand_copy_to_sdram(PAGE_SIZE*4, 0x50000000+PAGE_SIZE, rest);
}
unsigned int store2nand(unsigned long ddr_start, unsigned long length){
	unsigned char* src = (unsigned char*)ddr_start;
	unsigned long rest = length;
	unsigned long size;
	unsigned long i;
	unsigned long blocks = (length+8*1024+0x100000-1)/0x100000;

	for(i = 0; i != blocks; ++i){
		s3c6410_nand_erase(i*0x100000);
	}

	for(i = 0; i != 4; ++i){
		size = rest>2048?2048:rest;
		s3c6410_nand_write(PAGE_SIZE*i, src+2048*i, size);
		rest -= size;
		if(rest == 0)
		return 0;
	}

	s3c6410_nand_write(PAGE_SIZE*4, src+2048*4, rest);
    return 0;
}
