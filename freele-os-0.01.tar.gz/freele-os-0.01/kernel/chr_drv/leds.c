/*
leds.c:

Copyright (C) 2014  Michael. Th. Zhang <zth@pku.edu.cn> or <muge0913@sina.com>

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see http://www.gnu.org/licenses/.
*/


//没有虚拟地址映射时
#define rGPKCON0        (*(volatile unsigned *)(0x7F008800))
#define rGPKDAT         (*(volatile unsigned *)(0x7F008808))
#define rGPKPUD         (*(volatile unsigned *)(0x7F00880C))

/*
//有虚拟地址映射时
#define rGPKCON0        (*(volatile unsigned *)(0xAF008800))
#define rGPKDAT         (*(volatile unsigned *)(0xAF008808))
#define rGPKPUD         (*(volatile unsigned *)(0xAF00880C))
*/
void led_port_init(void){
	rGPKCON0 = (rGPKCON0 & ~(0xffffU<<16))|(0x1111U<<16);
	rGPKPUD  = (rGPKPUD  & ~(0xffU << 8))|(0x00U<<8);
}

void led_display(int data){
	rGPKDAT = (rGPKDAT & ~(0xf<<4)) | ((data & 0xf)<<4);
}
void led_delay(void){
	volatile unsigned int k;
	for(k = 0; k < 2000000; k++);
}
