/*
dr_frame.c:

Copyright (C) 2014  Michael. Th. Zhang <zth@pku.edu.cn> or <muge0913@sina.com>

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see http://www.gnu.org/licenses/.
*/

#include <dr_frame.h>

int storage_device_init(){
        for(int index = 0;index < MAX_STORAGE_DEVICE;index ++)
            storage[index] = NULL;
}
/* 存储设备注册函数 返回-1表示没有设备可再申请，返回0 说明返回成功
 * storage_device为要注册的设备结构体，device_id为注册设备号*/
int register_storage_device(struct storage_device *sd,unsigned int device_id){
    if(device_id < 0 || device_id > MAX_STORAGE_DEVICE)
		return -1;

	if(storage[device_id]){
		return -1;
	}else{
		storage[device_id]=sd;
	}
	return 0;
}
/* 存储设备取消注册函数 返回-1表示取消注册失败，返回0 说明取消成功
 * storage_device为要取消注册的设备结构体，device_id为注册设备号*/
int unregister_storage_device(struct storage_device *sd,unsigned int device_id){
	if(device_id <0 || device_id>MAX_STORAGE_DEVICE)
		return -1;

	if(storage[device_id]){
		storage[device_id] = NULL;
        return 0;
	}else{
		return -1;
	}
}
int read_storage_device(unsigned int device_id,void * buf,unsigned int addr,unsigned int size){
	if(device_id <0 || device_id>MAX_STORAGE_DEVICE)
		return -1;
    int ret = storage[device_id]->dout(storage[device_id],buf,addr,size);
    return ret;
}

int write_storage_device(unsigned int device_id,void * buf,unsigned int dest,unsigned int size){
	if(device_id <0 || device_id>MAX_STORAGE_DEVICE)
		return -1;
    int ret = storage[device_id]->din(storage[device_id],buf,dest,size);
    return ret;
}
