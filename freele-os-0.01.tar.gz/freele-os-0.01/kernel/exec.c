/*
exec.c:

Copyright (C) 2014  Michael. Th. Zhang <zth@pku.edu.cn> or <muge0913@sina.com>

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see http://www.gnu.org/licenses/.
*/


#include <elf.h>
#include <dr_frame.h>
#include <fs_frame.h>

extern void *kmalloc(unsigned int size);
extern void kfree(void *addr);
extern void printk(const char *fmt, ...);

int run(unsigned int start)
{
	__asm__ volatile(
            "mov pc,r0\n\t"
            );
	return 0;
}
int exec(unsigned char *binary_filename)
{
	unsigned char *buf;
	if((buf=kmalloc(1024))==(void *)0) {
		printk("get free pages error\n");
		goto ERROR;
	}

	struct inode *node = fs_type[ROMFS]->namei(fs_type[ROMFS],binary_filename);

	read_storage_device(fs_type[ROMFS]->device_id,buf,fs_type[ROMFS]->get_daddr(node),node->dsize);
	
	struct elf32_ehdr *ehdr=(struct elf32_ehdr *)buf;
	struct elf32_phdr *phdr=(struct elf32_phdr *)((unsigned char *)buf+ehdr->e_phoff);

	for(int i=0;i<ehdr->e_phnum;i++){
		if(CHECK_PT_TYPE_LOAD(phdr)){
			if(read_storage_device(fs_type[ROMFS]->device_id,(char *)phdr->p_vaddr,fs_type[ROMFS]->get_daddr(node) + phdr->p_offset,phdr->p_filesz)<0){
				printk("dout error\n");
				goto ERROR;
			}
			phdr++;
		}
	}

	return run(ehdr->e_entry);
ERROR:
	return -1;
}
int exec_for_test(unsigned int startaddr)
{

	__asm__ volatile(
            "mov pc,r0\n\t"
            );
	return 0;
}
