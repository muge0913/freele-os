/*
irq_k1.c:

Copyright (C) 2014  Michael. Th. Zhang <zth@pku.edu.cn> or <muge0913@sina.com>

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see http://www.gnu.org/licenses/.
*/



#include <irq.h>

/* 按键中断－－tiny6410k1*/
#define GPNCON      (*(volatile unsigned *)(0x7F008830))
#define GPNDAT      (*(volatile unsigned *)(0x7F008834))
#define GPNPUD      (*(volatile unsigned *)(0x7F008838))
/* 外部中断－－控制寄存器*/
#define EINT0CON0   (*(volatile unsigned *)(0x7F008900))
#define EINT0MASK   (*(volatile unsigned *)(0x7F008920))
#define EINT0PEND   (*(volatile unsigned *)(0x7F008924))

#define EINT_K1		(0)
extern void printk(const char *fmt, ...);
/* 中断服务程序 k1*/
void eint0_3_irq(void){
	save_context();
    disable_irq();

	//EINT0PEND[3--0]对应外部中断3－－0
	for (int i = 0; i < 4; i ++){
		if (EINT0PEND & (1<<i)){
			printk("exteranl interrupt:%d\n\r",i);
			EINT0PEND   |= 0x01;  /* 清中断 */
		}
	}
	
	finish_service_routine();
    enable_irq();
	restore_context();
}
void irq_k1_init(void){

/*
 * 外部引脚，及中断寄存器配置
 */

	/* 配置GPN0为外部中断0*/
	GPNCON &= ~(0x3);
	GPNCON |= (1<<1);
	GPNPUD &= ~(0x3);//10 = pull-up enabled
	GPNPUD |= (1<<1);
    /* 下降沿出发中 01x = Falling edge triggered*/
    EINT0CON0 &= ~(0X07);
    EINT0CON0 |= 3;
	/* 延时滤波*/
    EINT0FLTCON0 &=~(1<<6);
	EINT0FLTCON0 |=(1<<7); 
    /* 使能外部中断0*/
	EINT0MASK &= ~(1<<0);
/*
 * 中断控制器配置
 */

	/* 设置为irq中断*/
    select_irq_int(EINT_K1);
	/* 设置中断服务程序地址*/
	set_service_routine(EINT_K1, eint0_3_irq);
	/* 在中断控制器里使能中断，0位控制着外部中断0－－3 ，1位控制着外部中断4－－11*/
	enable_int(EINT_K1);
}
