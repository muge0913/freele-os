/*
sys_timer.c:

Copyright (C) 2014  Michael. Th. Zhang <zth@pku.edu.cn> or <muge0913@sina.com>

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see http://www.gnu.org/licenses/.
*/



#include <irq.h>
#include <sched.h>
#define TCFG0  		    (*(volatile unsigned *)(0x7F006000))
#define TCFG1  		    (*(volatile unsigned *)(0x7F006004))
#define TCON  		    (*(volatile unsigned *)(0x7F006008))
#define TCNTB0  	    (*(volatile unsigned *)(0x7F00600C))
#define TCMPB0  	    (*(volatile unsigned *)(0x7F006010))
#define TINT_CSTAT  	(*(volatile unsigned *)(0x7F006044))
#define SYS_TIMERO 	    (23)

extern void printk(const char *fmt, ...);
static unsigned int index_for_sched = 0;
/* timer0中断函数,用于系统时钟*/
void sys_timer0(){
    save_context_for_sched(index_for_sched % MAX_TASK_NUM);

    index_for_sched ++;
	TINT_CSTAT|=(1<<5);
	finish_service_routine();

    restore_context_for_sched((index_for_sched) % MAX_TASK_NUM);
}
void sys_timer0_init(){
	/* 打开timer0*/
	TINT_CSTAT |= (1<<0);
	/* 设置预定标器Prescaler=65*/
	TCFG0 &= 0x00;
	TCFG0 = 65;
	/* 设置分频器MUX=1/16*/
	TCFG1 |= (4<<0);
	/* 设置初值 1s*/
	TCNTB0 = 62500;
	/* 设置比较值*/
	TCMPB0 = 0;
	/* Auto-Reload，Updata TCNTB0，TCMPB0，Start Timer0*/
	TCON |= (0xb<<0);
	TCON &=~(1<<1);
	/* 清除中断标志位*/
	TINT_CSTAT|=(1<<5);
/*
 * 中断控制器配置
 */

	set_service_routine(SYS_TIMERO,sys_timer0);
	enable_int(SYS_TIMERO);
}
