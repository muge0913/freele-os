/*
task_one.c:

Copyright (C) 2014  Michael. Th. Zhang <zth@pku.edu.cn> or <muge0913@sina.com>

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see http://www.gnu.org/licenses/.
*/


// UART0
#define UART0_BASE  	(0x7F005000) //实际物理基地址
#define rUTRSTAT0	    (*(volatile unsigned *)(UART0_BASE+0x10))
#define WrUTXH0(ch)     (*(volatile unsigned char *)(UART0_BASE+0x20))=(unsigned char)(ch)

int main()
{
    while(1) {
        while(!(rUTRSTAT0 & 0x2));   //Wait until THR is empty.
    	WrUTXH0('A');
    }
    return 0;
}
