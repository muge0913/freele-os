#用于统计系统代码数量
#find -name "*.[S c h]"  -exec wc -l "{}" \; | awk '{s+=$1}END{print s}'
find . -name '*.[S c h]' | xargs  wc -l;
