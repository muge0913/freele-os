void download()
{
   uart0_send_string("\n\rdownload the filesystem ? y or n\n\r");
   if ('y' == uart0_get_byte()) {
    /* downloading the filesystem ...*/
  	/* filesystem defult size: 1MB */
	uart0_send_string("download the filesystem ...\n\r");
	download_file_system(0x100000);
	uart0_send_string("download done!\n\r");
	uart0_send_string("please reboot the system and donwload the kernel with dnw!\n\r");
    while(1);// done
   } else {
    /* booting the kernel ...*/
	uart0_send_string("booting the kernel ...\n\r");
   }
}
