#define PAGE_SIZE       8192

#define NFCONF 		(*(volatile unsigned long*)(0x70200000))
#define NFCONT 		(*(volatile unsigned long*)(0x70200004))
#define NFCMMD 		(*(volatile unsigned long*)(0x70200008))
#define NFADDR 		(*(volatile unsigned long*)(0x7020000C))
#define NFDATA 		(*(volatile unsigned char*)(0x70200010))
#define NFSTAT 		(*(volatile unsigned long*)(0x70200028))
#define GPOCON 		(*(volatile unsigned long*)(0x7F008140))
#define GPOPUD 		(*(volatile unsigned long*)(0x7F008148))
#define GPPCON 		(*(volatile unsigned long*)(0x7F008160))
#define GPPPUD 		(*(volatile unsigned long*)(0x7F008168))
#define MEM_SYS_CFG 	(*(volatile unsigned long*)(0x7E00F120))

/* �ȴ�NAND Flash���� */
static void  s3c6410_nand_for_boot_wait_idle(void){
    /* NFSTAT�Ĵ���0λΪ0��ʱ��Ϊbusy��1��ʱ��Ϊ���� */
    while(!(NFSTAT & 0x1));
}

/* ����Ƭѡ�ź� */
static void  s3c6410_nand_for_boot_select_chip(void){
    NFCONT &= ~(1<<1);   
}

/* ȡ��Ƭѡ�ź� */
static void  s3c6410_nand_for_boot_deselect_chip(void){
    NFCONT |= (1<<1);
}

/* �������� */
static void  s3c6410_nand_for_boot_write_cmd(unsigned char cmd){
    /* NFCMD�Ĵ����ǵ�8λ��Ч */
    NFCMMD = cmd;
}

/* ������ַ */
static void  s3c6410_nand_for_boot_write_addr(unsigned long addr){
    unsigned long row   = addr/PAGE_SIZE;
    unsigned long column = addr%PAGE_SIZE;
      
    NFADDR = column & 0xff;
    NFADDR = (column >> 8) & 0xff;

    NFADDR = row & 0xff;
    NFADDR = (row >> 8) & 0xff;
    NFADDR = (row >> 16) & 0xff;
}

/* ��λ */
static void  s3c6410_nand_for_boot_reset(void){
    
     s3c6410_nand_for_boot_select_chip();
     s3c6410_nand_for_boot_write_cmd(0xff);  // ��λ����
     s3c6410_nand_for_boot_wait_idle();
     s3c6410_nand_for_boot_deselect_chip();
}
/* ������������,nand_startΪԴ��ַ,�õ�ַ��nandflash�е�
 * ddr_startΪĿ���ַ���õ�ַ���ڴ��У�lenΪҪ��ȡ�ĳ���
 */
void  s3c6410_nand_for_boot_copy_to_sdram(unsigned int nand_start, unsigned int ddr_start, unsigned int len){
	unsigned long rest = len;
	unsigned long addr = nand_start;
	unsigned long page;
	unsigned char *dest = (unsigned char *)ddr_start;
	int i;

	s3c6410_nand_for_boot_select_chip();
	while(rest > 0){
		 s3c6410_nand_for_boot_write_cmd(0x00);
		 s3c6410_nand_for_boot_write_addr(addr);
		 s3c6410_nand_for_boot_write_cmd(0x30);
		 s3c6410_nand_for_boot_wait_idle();

		page = rest>PAGE_SIZE?PAGE_SIZE:rest;
		for(i = 0; i != page; ++i){
			*dest++ = NFDATA;
		}
		rest -= page;
		addr += page;
	}
	 s3c6410_nand_for_boot_deselect_chip();
}
/* ������������,nand_startΪĿ���ַ,�õ�ַ��nandflash�е�
 * bufΪҪд������ݣ�lenΪҪ��ȡ�ĳ���
 */
void s3c6410_nand_for_boot_copy_to_nand(unsigned int nand_start, unsigned char * buf, unsigned int len)
{
	unsigned long count = 0;
	unsigned long addr  = nand_start;
	int i = nand_start % PAGE_SIZE;

	s3c6410_nand_for_boot_select_chip();
	while (count < len)
	{
		s3c6410_nand_for_boot_write_cmd(0x80);
		s3c6410_nand_for_boot_write_addr(addr);
		for (; i < PAGE_SIZE && count < len; i++)
		{
			NFDATA = buf[count++];
			addr++;
		}
		s3c6410_nand_for_boot_write_cmd(0x10);
		s3c6410_nand_for_boot_wait_idle();
		i = 0;
	}
	s3c6410_nand_for_boot_deselect_chip();
}

/* final API*/
void  s3c6410_nand_for_boot_init(){
#define TACLS 7
#define TWRPH0 7
#define TWRPH1 7

	GPOCON = (GPOCON & ~0xf) | 0xa;//nCS[3:2]
	GPOPUD &= ~0xf;
	GPPCON = (GPPCON & ~(0xfff << 4)) | (0xaaa << 4);//nWAIT, FALE, FCLE,
	GPPPUD &= ~(0xfff << 4);//FWEn, FREn, FRnB

	MEM_SYS_CFG &= ~(1<<1);
	NFCONF &= ~((0x7<<4)|(0x7<<8)|(0x7<<12)|(1<<30));
	NFCONF |= (TWRPH1<<4)|(TWRPH0<<8)|(TACLS<<12);
	NFCONT |= 1;
	NFCONT &= ~(1<<16);
         /* ��λNAND Flash */
         s3c6410_nand_for_boot_reset();

}
/* ��nand�е�0��ַ����length�������ݶ�ȡ��sdram��0��ַ�� */
void copy_kernel_codes(unsigned long length){

	 s3c6410_nand_for_boot_copy_to_sdram(0x400000, 0x50000000,length);
}

void download_file_system(int length)
{
	/* �ļ�ϵͳ��Ĭ�ϵ�ַ0x400000, */
	unsigned char *pchar=(unsigned char*)0x50100000;
	s3c6410_nand_for_boot_copy_to_sdram(0x400000, 0x50100000,length);
	s3c6410_nand_for_boot_copy_to_nand(0x3000000,pchar, length);
}


