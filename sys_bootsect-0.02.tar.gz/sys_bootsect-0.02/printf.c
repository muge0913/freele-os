// GPIO
#define GPIO_BASE	    (0x7F008000)
#define rGPACON		    (*(volatile unsigned *)(GPIO_BASE+0x00))
#define rGPADAT		    (*(volatile unsigned *)(GPIO_BASE+0x04))
#define rGPAPUD		    (*(volatile unsigned *)(GPIO_BASE+0x08))
// UART0
#define UART0_BASE	    (0x7F005000)
#define rULCON0		    (*(volatile unsigned *)(UART0_BASE+0x00))
#define rUCON0		    (*(volatile unsigned *)(UART0_BASE+0x04))
#define rUFCON0	        (*(volatile unsigned *)(UART0_BASE+0x08))
#define rUMCON0		    (*(volatile unsigned *)(UART0_BASE+0x0C))
#define rUTRSTAT0	    (*(volatile unsigned *)(UART0_BASE+0x10))
#define rUERSTAT0	    (*(volatile unsigned *)(UART0_BASE+0x14))
#define rUFSTAT0	    (*(volatile unsigned *)(UART0_BASE+0x18))
#define rUMSTAT0	    (*(volatile unsigned *)(UART0_BASE+0x1C))
#define rUTXH0		    (*(volatile unsigned *)(UART0_BASE+0x20))
#define rURXH0		    (*(volatile unsigned *)(UART0_BASE+0x24))
#define rUBRDIV0        (*(volatile unsigned *)(UART0_BASE+0x28))
#define rUDIVSLOT0	    (*(volatile unsigned *)(UART0_BASE+0x2C))
#define rUINTP0		    (*(volatile unsigned *)(UART0_BASE+0x30))
#define rUINTSP0        (*(volatile unsigned *)(UART0_BASE+0x34))
#define rUINTM0		    (*(volatile unsigned *)(UART0_BASE+0x38))

#define WrUTXH0(ch)     (*(volatile unsigned char *)(UART0_BASE+0x20))=(unsigned char)(ch)
#define RdURXH0()       (*(volatile unsigned char *)(UART0_BASE+0x24))

void uart0_init()
{
	/*将GPA0、GPA1、GPA2、GPA3设为对应功能引脚RXD[0],TXD[0],CTSn[0],RTSn[0]*/
	// GPA0->RXD0, GPA1->TXD0
	rGPACON = (rGPACON & ~(0xff<<0)) | (0x22<<0);
	// RXD0: Pull-down, TXD0: pull up/down disable
	rGPAPUD = (rGPAPUD & ~(0xf <<0)) | (0x1<<0);

	// Normal Mode, No Parity, 1 Stop Bit, 8 Bit Data
	rULCON0 = (0<<6)|(0<<3)|(0<<2)|(3<<0);
	// PCLK divide, Polling Mode
	rUCON0 = (0<<10)|(1<<9)|(1<<8)|(0<<7)|(0<<6)|(0<<5)|(0<<4)|(1<<2)|(1<<0);
	// disable fifo
	rUFCON0 = (0<<6)|(0<<4)|(0<<2)|(0<<1)|(0<<0);
 	// Disable Auto Flow Control
	rUMCON0 = (0<<5)|(0<<4)|(0<<0);                       

	rUBRDIV0 = 35;    // Baud rate
	rUDIVSLOT0 = 0x80;//aSlotTable[DivSlot];
}
void uart0_send_byte(unsigned char byte)
{
    while(!(rUTRSTAT0 & 0x2));   //Wait until THR is empty.
    WrUTXH0(byte);
}
void uart0_send_string(char *pt) 
{
    while(*pt)uart0_send_byte(*pt++);
}
unsigned char uart0_get_byte()
{
	while((rUFSTAT0 & 0x7f) == 0);
	return RdURXH0();
}
